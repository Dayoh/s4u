import requests
import json
import re
import string
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

DOMAIN = 'https://seasons4u.com/'
PATH = 'api/apps/v1/'
VERSION = '3.3.0'

class S4U(object):
    token = ''
    def __init__(self, username, password):
        self.username = username
        self.password = password
    def getToken(self, firstLoad):
        with requests.Session() as s:
            if firstLoad == True and self.token <> '':
                return
            auth_values = {
                'username': self.username,
                'password': self.password,
                'grant_type': 'password'
            }
            response = s.post(DOMAIN + '/Token', data=auth_values)    
            if str(response).find('[401]') > 0 or str(response).find('[400]') > 0:                   
                xbmcgui.Dialog().ok('S4U', 'Incorrect Credentials.')
                raise ValueError('Incorrect Credentials')
                return   
            if str(response).find('[409]') > 0:                   
                xbmcgui.Dialog().ok('Locked out', 'Please close other devices and try again in a few minutes.')
                raise ValueError('Lockout')
                return
            if str(response).find('[417]') > 0:                   
                xbmcgui.Dialog().ok('S4U', 'Please make sure your IP is unlocked.')
                raise ValueError('Lock')
                return     
            temp = json.loads(response.content)
            self.token = 'Bearer ' + temp['access_token']
    def openResource(self, url):
        with requests.Session() as s: 
            attemps = 0
            success = False
            while attemps < 2 and success == False:
                success = True
                attemps = attemps + 1
                response = s.post(url, data='', headers={
                    'Authorization': self.token,
                })            
                if str(response).find('[401]') > 0 or str(response).find('[400]') > 0:   
                    success = False
                    if self.token == '' or attemps == 2:
                        xbmcgui.Dialog().ok('S4U', 'Incorrect Credentials')
                        return ''  
                if str(response).find('[409]') > 0:                   
                    xbmcgui.Dialog().ok('Locked out', 'Please close other devices and try again in a few minutes.')
                    raise ValueError('Lockout')
                    return
                if str(response).find('[417]') > 0:                   
                    xbmcgui.Dialog().ok('S4U', 'Please make sure your IP is unlocked.')
                    raise ValueError('Lock')
                    return     
            return response.content       
    def getVid(self, type, code, quality):        
        response = self.openResource(DOMAIN + PATH + 'Watch/' + type + '/' + code + '/' + str(quality))
        if response == '':
            return response
        return response.replace('"','')
    def getMenu(self, parent, options):        
        response = self.openResource(DOMAIN + PATH + 'Menu/' + parent + '?version=' + VERSION + '&options=' + options)
        if response == '':
            return response
        return  json.loads(response)



