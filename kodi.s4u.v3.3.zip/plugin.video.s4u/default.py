﻿import xbmcgui
import xbmc
import xbmcaddon
import xbmcplugin

import sys
import urlparse
import urllib
import json
import s4u

import inputstreamhelper
import time

HOME = 'home'
WATCH = 'watch'
QSETTING = 'qsetting'
MESSAGE = 'message'

base_url = sys.argv[0]
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

quality = addon.getSetting('quality')


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


def play_video(link, title, image):

    if '.mpd' in link:
        li = xbmcgui.ListItem(label=title, iconImage=image,
                              thumbnailImage=image, path=link)
        li.setInfo(type='Video', infoLabels={"Title": title})
        if '.m3u8' in link:
            is_helper = inputstreamhelper.Helper('hls', drm='widevine')
        else:
            is_helper = inputstreamhelper.Helper('mpd', drm='widevine')

        linkParams = link.split("||||")

        if is_helper.check_inputstream():
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            if '.m3u8' in link:
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            else:
                li.setProperty('inputstream.adaptive.manifest_type', 'mpd')

            li.setProperty('inputstream.adaptive.license_type',
                           'com.widevine.alpha')

            # li.setProperty('inputstream.adaptive.manifest_type', 'mpd')

            li.setContentLookup(False)
            li.setProperty(
                'inputstream.adaptive.manifest_update_parameter', 'full')
            licUrl = linkParams[1]
            li.setProperty('inputstream.adaptive.license_key', licUrl)
            # li.setMimeType('application/dash+xml')

            # xbmcplugin.setResolvedUrl(handle=int(
            # sys.argv[1]), succeeded=True, listitem=li)

            # while not xbmc.Player().isPlayingVideo():
            #     xbmc.Monitor().waitForAbort(0.25)

            # if xbmc.Player().isPlayingVideo() and len(xbmc.Player().getAvailableAudioStreams()) > 1:
            #     xbmc.Player().setAudioStream(0)

            xbmc.Player().play(item=linkParams[0], listitem=li)

            seekloop = False

            while not xbmc.Player().isPlayingVideo():
                seekloop = False
                # xbmc.Monitor().waitForAbort(5)
            # xbmc.Monitor().waitForAbort(3)
            print('Applying seek2')
            print(xbmc.Player().getTime())
            # xbmc.Player().seekTime(180)
            xbmc.Player().seekTime(180)

            # while xbmc.Player().isPlayingVideo() and not xbmc.Monitor().abortRequested():
            #     position = int(float(xbmc.Player().getTime()))
            #     duration = int(float(xbmc.Player().getTotalTime()))
            #     print('yayayaya')
            #     print(position)
            #     print(duration)
            #     xbmc.Monitor().waitForAbort(3)

            # if xbmc.Player().isPlayingVideo():
            #     xbmc.Player().seekTime(150);

            # xbmc.Player().seekTime(150);
            # while xbmc.Player().isPlayingVideo() and not xbmc.Monitor().abortRequested():
            #     print('Yabadaada')
            #     xbmc.Monitor().waitForAbort(3)
            # play_back_started = time.time()
            # print('*****/////*******')
            # print(play_back_started)
            # while xbmc.Player().isPlayingVideo() and not xbmc.Monitor().abortRequested():
            #     position = int(float(xbmc.Player().getTime()))
            #     duration = int(float(xbmc.Player().getTotalTime()))
            #     print(position)
            #     print(duration)
            #     xbmc.Monitor().waitForAbort(3)
    else:
        # li = xbmcgui.ListItem(label=title, iconImage=image,
        #                       thumbnailImage=image, path=link)
        # li.setInfo(type='Video', infoLabels={"Title": title})
        # li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        # li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # xbmc.Player().play(item=link, listitem=li)
        li = xbmcgui.ListItem(label=title, iconImage=image,
                              thumbnailImage=image, path=link)
    li.setInfo(type='Video', infoLabels={"Title": title})
    xbmc.Player().play(item=link, listitem=li)


def show_main_menu():
    menu = app.getMenu('0', '')
    for m in menu:
        list_item = xbmcgui.ListItem(m["Description"])
        list_item.setArt({'fanart': addon.getAddonInfo('fanart')})
        xbmcplugin.addDirectoryItem(handle=addon_handle,
                                    url=build_url({'mode': m["Id"]}),
                                    listitem=list_item,
                                    isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)


def show_menu(id):

    cacheToDisc = True
    options = ''

    if not args.get('options') is None:
        options = args.get('options')[0]

    menu = app.getMenu(id, options)

    for m in menu:

        description = m["Description"]

        list_item = xbmcgui.ListItem(
            description, iconImage=m["Image"], thumbnailImage=m["Image"])
        list_item.setArt({'fanart': addon.getAddonInfo('fanart')})
        if m["Type"] == 0:
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'mode': m["Id"]}),
                                        listitem=list_item,
                                        isFolder=True)
        elif m["Type"] == 1:
            url = build_url({
                'mode': WATCH,
                'id': m["VideoId"],
                'type': m["VideoType"],
                'title': m["Description"],
                'image': m["Image"]
            })
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=url,
                                        listitem=list_item,
                                        isFolder=True)
        elif m["Type"] == 2:
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'mode': m["Id"],
                                                       'options': m["Options"]}),
                                        listitem=list_item,
                                        isFolder=True)

        elif m["Type"] == 3:
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'mode': m["Id"]}),
                                        listitem=list_item,
                                        isFolder=True)
        elif m["Type"] == 4:

            if quality == m["Options"]:
                list_item = xbmcgui.ListItem(m["Description"] + ' [SELECTED]')
                list_item.setArt({'fanart': addon.getAddonInfo('fanart')})

            cacheToDisc = False
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'mode': 'qsetting',
                                                       'value': m["Options"]
                                                       }),
                                        listitem=list_item,
                                        isFolder=True)
        elif m["Type"] == 5:
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'mode': 'message',
                                                       'title': m["Options"],
                                                       'message': m["Message"]
                                                       }),
                                        listitem=list_item,
                                        isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=cacheToDisc)


def showMessage():
    title = args.get('title')[0]
    msg = args.get('message')[0]
    xbmcgui.Dialog().ok(title, msg)
    return


def setQuality():
    value = args.get('value')[0]

    addon.setSetting('quality', value)
    quality = addon.getSetting('quality')
    xbmcgui.Dialog().ok("S4U", "Quality updated!")
    return


def play():
    id = args.get('id')[0]
    type = args.get('type')[0]
    title = args.get('title')[0]
    if not args.get('image') is None:
        image = args.get('image')[0]
    else:
        image = ''
    link = app.getVid(type, id, quality)
    play_video(link, title, image)


def get_s4u_app():
    username = addon.getSetting('username')
    password = addon.getSetting('password')
    s4u_app = s4u.S4U(username, password)
    s4u_app.getToken(True)
    return s4u_app


app = get_s4u_app()
mode = args.get('mode', None)
mode = mode[0] if mode else HOME

if mode == HOME:
    show_main_menu()
elif mode == WATCH:
    play()
elif mode == QSETTING:
    setQuality()
elif mode == MESSAGE:
    showMessage()
else:
    show_menu(mode)
